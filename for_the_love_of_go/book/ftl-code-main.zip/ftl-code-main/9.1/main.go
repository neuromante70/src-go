package main

import "fmt"

func main() {
	var title string
	var copies int
	title = "The Happiness Project"
	copies = 99
	fmt.Println(title)
	fmt.Println(copies)
}
