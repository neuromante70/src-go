package mytypes

// Twice multiplies its receiver by 2 and returns
// the result.
func (i int) Twice() int {
	return i * 2
}
