package mytypes

func Double(input *int) {
	*input *= 2
}
