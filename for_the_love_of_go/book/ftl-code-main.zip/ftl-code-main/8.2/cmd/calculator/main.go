package main

import (
	"calculator"
	"fmt"
)

func main() {
	result := calculator.Add(2, 2)
	fmt.Println(result)
}
