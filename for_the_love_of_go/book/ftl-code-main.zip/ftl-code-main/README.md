# For the Love of Go - code listings

[![Cover image](cover_small.png)](https://bitfieldconsulting.com/books/love)

This is a collection of code samples, listings, and solutions to challenges from the book 'For the Love of Go', by John Arundel.

You can buy the book here:

* [For the Love of Go](https://bitfieldconsulting.com/books/love)
