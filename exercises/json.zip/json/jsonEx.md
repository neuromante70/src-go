{
	"person": {
		"firstname": "Captain",
		"middlename": null,
		"lastname": "Marvel",
		"age": 32,
		"isMarried": false,
		"hobbies": ["Go", "Saving Earth", "Shield"]
	}
}
