package calc

import (
	"fmt"
	"io/ioutil"
	"encoding/json"
	//"encoding/json"
)

var prt = fmt.Println

/*
1. Create a MathRequest struct - this will have two integers and an operation string - this is how we will model all the add/mult/sub/divide requests that come into the calculator.
So an add function call will create a math request where the two ints are the two inputs and the operation is "add"
*/

type MathRequest struct {
	num1     int
	num2     int
	operator string
}

/*
2. In the CalculatorA struct create a slice of math requests named history - this is where we will append all math requests that are created in the different functions - so this will be our list of history
*/

type Calculator struct {
	History []MathRequest
}

var MyCalc Calculator

func (c Calculator) Add(num1 int, num2 int) int {
	op := MathRequest{num1, num2, "add"}
	MyCalc.History = append(MyCalc.History, op)
	return num1 + num2
}

func (c Calculator) Sub(num1 int, num2 int) int {
	op := MathRequest{num1, num2, "sub"}
	MyCalc.History = append(MyCalc.History, op)
	return num1 - num2
}

func (c Calculator) Molt(num1 int, num2 int) int {
	op := MathRequest{num1, num2, "molt"}
	MyCalc.History = append(MyCalc.History, op)
	return num1 * num2
}

func (c Calculator) Divide(num1 int, num2 int) int {
	if num2 == 0 {
		prt("impossible to divide by zero")
		return 0
	} else {
		op := MathRequest{num1, num2, "div"}
		MyCalc.History = append(MyCalc.History, op)
		return num1 / num2
	}
}

func (c Calculator) PrintHistory() (history []string) {
	// for i := 0; i < len(MyCalc.History); i++ {
	// 	history[i] = fmt.Sprintf("%+v", MyCalc.History[i])
	// 	prt(MyCalc.History[i])
	// 	prt(history[i])
	// }
	for _, v := range MyCalc.History {
		history = append(history, fmt.Sprintf("%+v", v))
	}
	// history = fmt.Sprintf("%+v", MyCalc.History)
	// (history []string)
	// calc.MathRequest
	return history
	// prt(len(MyCalc.History))
	// prt(MyCalc.History)
	// fmt.Printf("%#v %T", MyCalc.History, MyCalc.History)
}

func (c Calculator) PrinToFile() {
	culo := MyCalc.PrintHistory()
	dec := json.NewDecoder(culo)
	dec.decode(&MyCalc.History)
	_ = ioutil.WriteFile("calcHistory.json", file, 0644)
}
